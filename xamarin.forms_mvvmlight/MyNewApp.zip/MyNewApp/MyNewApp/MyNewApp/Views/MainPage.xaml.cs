﻿using Xamarin.Forms;

namespace MyNewApp.Views
{
	public partial class MainPage : ContentPage
	{
		public MainPage()
		{
			InitializeComponent();
			BindingContext = App.Locator.Main;
		}
	}
}
