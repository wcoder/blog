﻿using System.ComponentModel;
using System.Linq;
using System.Windows;
using Microsoft.Phone.Controls;

namespace POCWP8Confirm
{
	public partial class MainPage : PhoneApplicationPage
	{
		public MainPage()
		{
			InitializeComponent();
		}

		private void PhoneApplication_OnBackKeyPress(object sender, CancelEventArgs e)
		{
			var message = "Are you sure?";
			var title = "Exit?";

			if (MessageBox.Show(message, title, MessageBoxButton.OKCancel) == MessageBoxResult.OK)
			{
				ClearBackEntries();
			}
			else { 
				e.Cancel = true;
			}
		}

		private void ClearBackEntries()
		{
			while (NavigationService.BackStack != null
				&& NavigationService.BackStack.Any())
				NavigationService.RemoveBackEntry();
		}
	}
}